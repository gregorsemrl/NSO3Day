package com.tailf.packages.ned.ios;

import com.tailf.packages.ned.nedcom.NedComCliBase;

import static com.tailf.packages.ned.nedcom.NedString.stringQuote;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.LinkedList;

import com.tailf.ned.NedWorker;
import com.tailf.ned.NedException;


/**
 * NedCmd
 *
 */
@SuppressWarnings("deprecation")
public class NedDiff {

    private static final String META_DATA = "! meta-data :: ";

    /*
     * Local data
     */
    private IOSNedCli owner;
    private ArrayList<String> toprules = new ArrayList<>();
    private HashMap<String, ArrayList<String>> subrules = new HashMap<>();

    private int searched;
    private int moved;

    private Pattern lookupPa;
    private int lookupOp;

    /**
     * Constructor
     */
    NedDiff(IOSNedCli owner) {
        this.owner = owner;
    }


    /**
     * Rules to String
     * @param
     * @return
     */
    @SuppressWarnings("unchecked")
    public String toString() {

        // Top rules:
        StringBuilder sb = new StringBuilder("DIFF DEPENDENCY RULES:\n");
        Iterator<String> it = toprules.iterator();
        sb.append("   +++ Top rules:\n");
        while (it.hasNext()) {
            String rule = it.next();
            sb.append("     "+rule+"\n");
        }

        // Sub-mode rules:
        Iterator hit = subrules.entrySet().iterator();
        while (hit.hasNext()) {
            Map.Entry entry = (Map.Entry)hit.next();
            String mode = (String)entry.getKey();
            sb.append("   +++ "+stringQuote(mode)+" rules:\n");
            ArrayList<String> rules = (ArrayList<String>)entry.getValue();
            it = rules.iterator();
            while (it.hasNext()) {
                String rule = it.next();
                sb.append("     "+rule+"\n");
            }
        }

        return sb.toString();
    }


    /**
     * Add top node rule
     * @param
     * @return
     */
    public void add(String rule) {
        toprules.add(rule);
    }


    /**
     * Add sub node rule
     * @param
     * @return
     */
    public void add(String mode, String rule) {
        ArrayList<String> list = subrules.get(mode);
        if (list == null) {
            list = new ArrayList<>();
        }
        list.add(rule);
        subrules.put(mode, list);
    }


    /**
     * Reorder output data
     * @param
     * @return
     * @throws NedException
     */
    @SuppressWarnings("unchecked")
    public String reorder(NedWorker worker, String data) throws NedException {
        final long perf = owner.tick(0);
        owner.traceInfo(worker, "BEGIN DIFF reorder");
        this.searched = 0;
        this.moved = 0;

        // Reorder sub mode(s)
        Iterator it = subrules.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry)it.next();
            ArrayList<String> rules = (ArrayList<String>)entry.getValue();
            data = reorderMode(worker, rules, "top", (String)entry.getKey(), data);
        }

        // Reorder top mode
        data = reorderMode(worker, toprules, "top", "", data);

        owner.traceInfo(worker, "DONE DIFF reorder - "+this.moved+"/"+this.searched+" moved/searched in "+tickToString(perf));
        return "\n" + data;
    }


    /**
     * Reorder output data in a mode
     * @param
     * @return
     * @throws NedException
     */
    private String reorderMode(NedWorker worker, ArrayList<String> rules, String modename, String mode, String data)
        throws NedException {

        if (mode.isEmpty()) {
            owner.traceVerbose(worker, "\n-- Diff reordering "+modename+":");
        } else {
            owner.traceVerbose(worker, "\n-- Diff reordering "+modename+" / "+stringQuote(mode)+" modes:");
        }

        //
        // Populate config in a top node list
        //
        String[] lines = data.split("\n");
        StringBuilder sb;
        LinkedList<String> cfg = new LinkedList<>();
        for (int n = 0; n < lines.length; ) {
            sb = new StringBuilder();

            // Add meta-data lines + config line
            for (; n < lines.length; n++) {
                if (lines[n].isEmpty()) {
                    continue;
                }
                sb.append(lines[n]+"\n");
                if (!lines[n].startsWith(META_DATA)) {
                    break;
                }
            }

            // Add optional sub-mode lines
            for (n = n + 1; n < lines.length; n++) {
                if (lines[n].isEmpty()) {
                    continue;
                } else if (lines[n].startsWith(" ") || isTopExit(lines[n])) {
                    sb.append(lines[n]+"\n");
                } else {
                    break;
                }
            }

            // Add the line | mode-block
            cfg.add(sb.toString());
        }

        // Debug2
        Iterator<String> it = cfg.iterator();
        for (int i = 0; it.hasNext(); i++) {
            owner.traceDebug2(worker, "  Diff entry["+i+"] = "+stringQuote(it.next()));
        }

        //
        // Sub-mode reorder
        //
        if (!mode.isEmpty()) {

            // Strip this mode to create new submode String
            String[] modes = mode.split(" :: ");
            String submode = "";
            for (int s = 1; s < modes.length; s++) {
                if (s > 1) {
                    submode += " :: ";
                }
                submode += modes[s];
            }

            // Scan all top-mode config
            String[] mode0 = modes[0].split(" ,, ");
            String regex = "^"+mode0[0];
            Pattern p = Pattern.compile(regex);
            owner.traceDebug2(worker, "  Sub-mode lookup: "+stringQuote(regex));
            for (int i = 0; i < cfg.size(); i++) {
                String subdata = cfg.get(i);

                // Check mode condition (mode [:: condition])
                if (mode0.length > 1
                    && !subdata.contains(" "+mode0[1]) && !subdata.contains(" no "+mode0[1])) {
                    continue;
                }

                // Check if mode (must be minimum 3 lines and contain indented line)
                String[] sublines = subdata.split("\n");
                if (sublines.length < 3 || !subdata.contains("\n ")) {
                    continue;
                }

                // Fast-forward past all meta-data statements to mode header line
                int start = 0;
                while (start < (sublines.length-1) && sublines[start].startsWith(META_DATA)) {
                    start++;
                }

                // Check if matching mode
                Matcher m = p.matcher(sublines[start]);
                if (m.find()) {
                    owner.traceDebug2(worker, "  Sub-mode match: "+stringQuote(m.group(0)));

                    // Add header, sub-mode and footer config
                    StringBuilder header = new StringBuilder();
                    for (int s = 0; s <= start; s++) {
                        header.append(sublines[s]+"\n");
                    }
                    StringBuilder sub = new StringBuilder();
                    for (int s = start + 1; s < sublines.length - 1; s++) {
                        sub.append(sublines[s].substring(1)+"\n");
                    }
                    final String footer = sublines[sublines.length-1];

                    // Reorder sub-mode
                    subdata = reorderMode(worker, rules, modeName(header.toString()), submode, sub.toString());

                    // Put back header & footer and shift sub-mode config 1 right
                    sublines = subdata.split("\n");
                    sub = new StringBuilder(header.toString());
                    for (int s = 0; s < sublines.length; s++) {
                        sub.append(" "+sublines[s]+"\n");
                    }
                    sub.append(footer+"\n");

                    // Update config
                    cfg.set(i, sub.toString());
                } else {
                    owner.traceDebug3(worker, "  Sub-mode: non-match: "+stringQuote(subdata));
                }
            }

            // Reordered sub-mode done, reassemble config
            return listToString(cfg);
        }


        //
        // Reorder this mode
        //
        if (owner.devTraceLevel >= owner.TRACE_DEBUG2) {
            it = rules.iterator();
            for (int i = 0; it.hasNext(); i++) {
                owner.traceDebug2(worker, "  Diff rule["+i+"] = "+stringQuote(it.next()));
            }
        }

        // Loop through the rules:
        Iterator rulesIt = rules.iterator();
        while (rulesIt.hasNext()) {
            String rule = (String)rulesIt.next();
            String[] tag = rule.split(" :: ");
            if (tag.length < 3) {
                throw new NedException("Diff ERROR, malformed rule: "+stringQuote(rule));
            }

            // Multiple rules using <NAME> annotation:
            if (tag[2].contains("<NAME>")) {

                // Create <NAME> list with unique matches
                Pattern p = Pattern.compile(tag[2].replace("<NAME>", "(\\S+)"));
                ArrayList<String> names = new ArrayList<>();
                Iterator<String> cfgIt = cfg.iterator();
                while (cfgIt.hasNext()) {
                    Matcher m = p.matcher(cfgIt.next());
                    if (m.find()) {
                        names.remove(m.group(1));
                        names.add(m.group(1));
                    }
                }

                // Loop through each new specific rule with <NAME> substituted
                Iterator nameIt = names.iterator();
                while (nameIt.hasNext()) {
                    String name = (String)nameIt.next();
                    rule = tag[0].replace("<NAME>", name)+" :: "+tag[1]+" :: "+tag[2].replace("<NAME>", name);
                    owner.traceDebug2(worker, "  doReorder <NAME> = "+name+" : "+rule);
                    doReorder(worker, cfg, rule);
                }
            }

            // Normal single entry rule:
            else {
                doReorder(worker, cfg, rule);
            }
        }

        // Re-assemble data
        return listToString(cfg);
    }


    /**
     * Reorder entry/entries
     *   Note: start and stop are included in the search.
     * @param
     * @return
     */
    private void doReorder(NedWorker worker, LinkedList<String> cfg, String rule) {

        // Rule tags:
        //   tag[0] = line to move
        //   tag[1] = before|after
        //   tag[2] = line to stay
        String[] tag = rule.split(" :: ");

        // before - move all 'move' entries to before first 'stay'
        if (tag[1].contains("before")) {
            int end = cfg.size()-1;
            int stay = lookup(worker, cfg, initLookup(tag[2]), 0, end);
            if (stay < 0) {
                return;
            }
            String stayE = cfg.get(stay);

            String line = initLookup(tag[0]);
            for (int i = stay + 1; i <= end; i++) {
                i = lookup(worker, cfg, line, i, end);
                if (i < 0) {
                    break;
                }
                String moveE = cfg.remove(i);

                // Move entry
                owner.traceInfo(worker, "transformed => Diff: moved "+stringQuote(moveE)
                                +" before "+stringQuote(stayE));
                cfg.add(stay, moveE); // Add before (= add at index, shift all after)
                stay = stay + 1;
                this.moved++;
            }
        }

        // after - move all 'move' entries to after last 'stay'
        else if (tag[1].contains("after")) {
            int stay = lookup(worker, cfg, initLookup(tag[2]), cfg.size()-1, 0);
            if (stay < 0) {
                return;
            }
            String stayE = cfg.get(stay);

            String line = initLookup(tag[0]);
            for (int i = stay - 1; i >= 0; i--) {
                i = lookup(worker, cfg, line, i, 0);
                if (i < 0) {
                    break;
                }
                String moveE = cfg.remove(i);

                // Move entry
                owner.traceInfo(worker, "transformed => Diff: moved "+stringQuote(moveE)
                                +" after "+stringQuote(stayE));
                stay = stay - 1;
                cfg.add(stay + 1, moveE); // Add after
                this.moved++;
            }
        }

        // first - move all 'move' entries first
        else if (tag[1].contains("first")) {
            int end = cfg.size()-1;
            int pos = 0;
            String line = initLookup(tag[0]);
            for (int i = 1; i <= end; i++) {
                i = lookup(worker, cfg, line, i, end);
                if (i < 0) {
                    break;
                }
                String moveE = cfg.remove(i);

                // Move entry first
                owner.traceInfo(worker, "transformed => Diff: moved "+stringQuote(moveE)+" first");
                cfg.add(pos++, moveE);
                this.moved++;
            }
        }

        // last - move all 'move' entries last
        else if (tag[1].contains("last")) {
            int end = cfg.size()-1;
            String line = initLookup(tag[0]);
            for (int i = 0; i <= end; end--) {
                i = lookup(worker, cfg, line, i, end);
                if (i < 0) {
                    break;
                }
                String moveE = cfg.remove(i);

                // Move entry last
                owner.traceInfo(worker, "transformed => Diff: moved "+stringQuote(moveE)+" last");
                cfg.add(moveE);
                this.moved++;
            }
        }
    }


    /**
     * Init lookup - prepare regex and pattern
     *
     * @return
     */
    private String initLookup(String regex) {
        this.lookupPa = null;
        if (regex.startsWith(">")) {
            this.lookupOp = 1;
            return regex.substring(1);

        } else if (regex.startsWith("=")) {
            this.lookupOp = 2;
            return regex.substring(1);

        } else if (regex.endsWith("<")) {
            this.lookupOp = 3;
            return regex.substring(0, regex.length()-1);

        } else {
            this.lookupOp = 0;
            regex = regex.replace("<LF>", "\n.*?");
            this.lookupPa = Pattern.compile(regex, Pattern.DOTALL);
            return regex;
        }
    }


    /**
     * Lookup entry
     *   Note: start and stop are included in the search.
     * @param
     * @return
     */
    private int lookup(NedWorker worker, LinkedList<String> cfg, String line, int start, int stop) {

        owner.traceDebug3(worker, "  Diff looking up["+lookupOp+"]: "+stringQuote(line)+" in range "+start+" - "+stop);

        // Find first match
        if (start <= stop) {
            for (int i = start; i <= stop; i++) {
                if (match(i, cfg, line)) {
                    return i;
                }
            }
        }

        // Find last match (e.g. search backwards)
        else {
            for (int i = start; i >= stop; i--) {
                if (match(i, cfg, line)) {
                    return i;
                }
            }
        }

        return -1;
    }


    /**
     * Match line
     * @param
     * @return
     */
    private boolean match(int i, LinkedList<String> cfg, String line) {

        this.searched++;
        String entry = stripMetaData((String)cfg.get(i));

        if (lookupOp == 1) {
            return entry.startsWith(line);
        } else if (lookupOp == 2) {
            return entry.trim().equals(line);
        } else if (lookupOp == 3) {
            return entry.trim().endsWith(line);
        }

        // Default to regex match
        Matcher m = lookupPa.matcher(entry);
        return m.find();
    }


    /**
     * List to String
     * @param
     * @return
     */
    private String listToString(LinkedList<String> list) {
        StringBuilder sb = new StringBuilder();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            sb.append(it.next());
        }
        return sb.toString();
    }


    /**
     * Strip meta-data
     * @param
     * @return
     */
    private String stripMetaData(String data) {
        String[] lines = data.split("\n");
        StringBuilder sb = new StringBuilder();
        for (int n = 0; n < lines.length; n++) {
            if (lines[n].trim().startsWith(META_DATA)) {
                continue;
            }
            sb.append(lines[n]+"\n");
        }
        return sb.toString();
    }


    /**
     * Return mode name
     * @param
     * @return
     */
    private String modeName(String data) {
        String[] lines = data.split("\n");
        int n;
        for (n = 0; n < lines.length - 1; n++) {
            if (!lines[n].startsWith(META_DATA)) {
                return stringQuote(lines[n]);
            }
        }
        return stringQuote(lines[n]);
    }


    /**
     * Check if line is top exit
     * @param
     * @return
     */
    private boolean isTopExit(String line) {
        line = line.replace("\r", "");
        if ("exit".equals(line)) {
            return true;
        }
        return "!".equals(line);
    }


    /**
     * Format passed time
     * @param
     * @return
     */
    private String tickToString(long start) {
        long stop = owner.tick(start);
        return String.format("[%d ms]", stop);
    }

}
