#!/bin/bash

cat <<EOF
Cisco IOS Software, NETSIM
EOF
