#!/bin/bash

cat <<EOF
EOF
